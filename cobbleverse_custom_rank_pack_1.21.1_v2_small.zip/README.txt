Cobbleverse Rank Pack

Minecraft Java / Fabric resource pack for custom rank icons.
Built for 1.21.1 using resource pack format 34.

Unicode mapping:
- builder: \uE001  actual_char=
- champion: \uE002  actual_char=
- elite: \uE003  actual_char=
- god: \uE004  actual_char=
- helper: \uE005  actual_char=
- legend: \uE006  actual_char=
- master: \uE007  actual_char=
- member: \uE008  actual_char=
- mod: \uE009  actual_char=
- noob: \uE00A  actual_char=
- overlord: \uE00B  actual_char=
- owner: \uE00C  actual_char=
- player: \uE00D  actual_char=
- pro: \uE00E  actual_char=
- tiktok: \uE00F  actual_char=
- ultimate: \uE010  actual_char=
- youtuber: \uE011  actual_char=

Example LuckPerms commands:
/lp group builder meta setprefix 100 " "
/lp group champion meta setprefix 99 " "
/lp group elite meta setprefix 98 " "
/lp group god meta setprefix 97 " "
/lp group helper meta setprefix 96 " "

Server properties example:
require-resource-pack=true
resource-pack=https://YOUR-DIRECT-DOWNLOAD-LINK.zip
resource-pack-sha1=PUT_SHA1_HERE